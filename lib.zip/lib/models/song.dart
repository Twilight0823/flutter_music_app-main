class Song {
  final String id;
  final String title;
  final String artist;

  Song({required this.id, required this.title, required this.artist});

  factory Song.fromAudiusJson(Map<String, dynamic> json) {
    return Song(
      id: json['id'].toString(),
      title: json['title'] ?? 'Unknown Title',
      artist: json['user']['name'] ?? 'Unknown Artist',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'artist': artist,
    };
  }

  factory Song.fromJson(Map<String, dynamic> json) {
    return Song(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      artist: json['artist'] ?? '',
    );
  }
}