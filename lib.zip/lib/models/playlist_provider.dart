// import 'package:flutter/foundation.dart';
// import 'song.dart';

// class PlaylistProvider with ChangeNotifier {
//   final List<Song> _playlist = [];
//   bool _isPublic = false;

//   List<Song> get playlist => _playlist;
//   bool get isPublic => _isPublic;

//   void addToPlaylist(Song song) {
//     if (!_playlist.any((s) => s.id == song.id)) {
//       _playlist.add(song);
//       notifyListeners();
//     }
//   }

//   void removeFromPlaylist(String songId) {
//     _playlist.removeWhere((s) => s.id == songId);
//     notifyListeners();
//   }

//   void toggleVisibility() {
//     _isPublic = !_isPublic;
//     notifyListeners();
//   }

//   String generateShareableLink() {
//     final encoded = Uri.encodeComponent(_playlist.map((e) => e.toJson()).toList().toString());
//     return 'https://my-music-app.com/playlist?data=$encoded&public=$_isPublic';
//   }

//   void clearPlaylist() {
//     _playlist.clear();
//     notifyListeners();
//   }
// }
