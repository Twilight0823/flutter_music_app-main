import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:just_audio/just_audio.dart';
import 'package:music_app/pages/playlistpage.dart';
import '../models/song.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _searchController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<Song> _songs = [];
  bool _isLoading = false;

  Future<void> _searchSongs(String query) async {
    setState(() => _isLoading = true);
    final url =
        'https://api.audius.co/v1/tracks/search?query=$query&app_name=flutter_music_app';
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final tracks = data['data'] as List;
      setState(() {
        _songs = tracks.map((t) => Song.fromAudiusJson(t)).toList();
      });
    } else {
      // handle error
    }
    setState(() => _isLoading = false);
  }

  void _playSong(Song song) async {
    final streamUrl =
        'https://api.audius.co/v1/tracks/${song.id}/stream?app_name=flutter_music_app';
    await _audioPlayer.setUrl(streamUrl);
    _audioPlayer.play();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('S P A T I P A Y'),
        actions: [
          IconButton(
            icon: const Icon(Icons.playlist_play),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PlaylistPage()),
            ),
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _searchController,
              onSubmitted: _searchSongs,
              decoration: InputDecoration(
                hintText: 'Search for songs...',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () => _searchSongs(_searchController.text),
                ),
              ),
            ),
          ),
          _isLoading
              ? const CircularProgressIndicator()
              : Expanded(
                  child: ListView.builder(
                    itemCount: _songs.length,
                    itemBuilder: (context, index) {
                      final song = _songs[index];
                      return ListTile(
                        title: Text(song.title),
                        subtitle: Text(song.artist),
                        trailing: IconButton(
                          icon: const Icon(Icons.play_arrow),
                          onPressed: () => _playSong(song),
                        ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}
