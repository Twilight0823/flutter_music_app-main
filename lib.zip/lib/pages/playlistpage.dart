import 'package:flutter/material.dart';
import 'package:music_app/models/playlist_model.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';

class PlaylistPage extends StatelessWidget {
  const PlaylistPage({super.key});

  @override
  Widget build(BuildContext context) {
    final playlistProvider = Provider.of<PlaylistProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Playlist'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () {
              final link = playlistProvider.generateShareableLink();
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Share Playlist'),
                  content: Text('Link: $link'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close'),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      body: ListView.builder(
        itemCount: playlistProvider.playlist.length,
        itemBuilder: (context, index) {
          final Song song = playlistProvider.playlist[index];
          return ListTile(
            title: Text(song.title),
            subtitle: Text(song.artist),
          );
        },
      ),
    );
  }
}
