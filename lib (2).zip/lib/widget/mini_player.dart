// import 'package:flutter/material.dart';
// import 'package:music_app/pages/song_page.dart';
// import 'dart:async';
// import '../services/audio_service.dart';
// import '../models/song.dart';

// class MiniPlayer extends StatefulWidget {
//   final Song? song;
  
//   const MiniPlayer({
//     Key? key,
//     this.song,
//   }) : super(key: key);

//   @override
//   State<MiniPlayer> createState() => _MiniPlayerState();
// }

// class _MiniPlayerState extends State<MiniPlayer> {
//   final AudioService _audioService = AudioService();
//   late StreamSubscription _positionSubscription;
//   late StreamSubscription _playbackStateSubscription;
//   Duration _position = Duration.zero;
//   Duration _duration = Duration.zero;
//   bool _isPlaying = false;

//   @override
//   void initState() {
//     super.initState();
    
//     // Listen to position changes
//     _positionSubscription = _audioService.player.positionStream.listen((position) {
//       if (mounted) {
//         setState(() {
//           _position = position;
//         });
//       }
//     });
    
//     // Listen to duration changes
//     _audioService.player.durationStream.listen((duration) {
//       if (mounted && duration != null) {
//         setState(() {
//           _duration = duration;
//         });
//       }
//     });
    
//     // Listen to playback state changes
//     _playbackStateSubscription = _audioService.player.playingStream.listen((playing) {
//       if (mounted) {
//         setState(() {
//           _isPlaying = playing;
//         });
//       }
//     });
    
//     // Initialize with current values
//     _updatePositionAndDuration();
//   }
  
//   Future<void> _updatePositionAndDuration() async {
//     final position = await _audioService.getCurrentPosition();
//     final duration = await _audioService.getDuration();
//     if (mounted) {
//       setState(() {
//         _position = position;
//         _duration = duration;
//         _isPlaying = _audioService.isPlaying;
//       });
//     }
//   }

//   @override
//   void dispose() {
//     _positionSubscription.cancel();
//     _playbackStateSubscription.cancel();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (!_audioService.isInitialized) {
//       return const SizedBox.shrink();
//     }
    
//     final Song song = widget.song ?? Song(
//       id: '0',
//       title: _audioService.currentTitle ?? 'Unknown Title',
//       artist: _audioService.currentArtist ?? 'Unknown Artist',
//       imageUrl: _audioService.currentImageUrl ?? '',
//       audioUrl: '',
//     );
    
//     return GestureDetector(
//       onTap: () {
//         Navigator.push(
//           context,
//           MaterialPageRoute(builder: (context) => SongPage(song: song)),
//         );
//       },
//       child: Container(
//         decoration: BoxDecoration(
//           color: Theme.of(context).cardColor,
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 8,
//               offset: const Offset(0, -2),
//             ),
//           ],
//         ),
//         padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             // Progress bar
//             LinearProgressIndicator(
//               value: _duration.inMilliseconds > 0 
//                   ? _position.inMilliseconds / _duration.inMilliseconds
//                   : 0.0,
//               backgroundColor: Colors.grey[300],
//               valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).primaryColor),
//               minHeight: 2,
//             ),
//             const SizedBox(height: 4),
//             // Player controls
//             Row(
//               children: [
//                 // Song image
//                 if (song.imageUrl.isNotEmpty)
//                   ClipRRect(
//                     borderRadius: BorderRadius.circular(4),
//                     child: Image.network(
//                       song.imageUrl,
//                       width: 40,
//                       height: 40,
//                       fit: BoxFit.cover,
//                       errorBuilder: (_, __, ___) => const Icon(Icons.music_note, size: 40),
//                     ),
//                   )
//                 else
//                   const Icon(Icons.music_note, size: 40),
//                 const SizedBox(width: 12),
//                 // Title and artist
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Text(
//                         song.title,
//                         style: const TextStyle(
//                           fontWeight: FontWeight.bold,
//                         ),
//                         maxLines: 1,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                       Text(
//                         song.artist,
//                         style: TextStyle(
//                           fontSize: 12,
//                           color: Colors.grey[600],
//                         ),
//                         maxLines: 1,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                     ],
//                   ),
//                 ),
//                 // Play/pause button
//                 IconButton(
//                   icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
//                   onPressed: () {
//                     if (_isPlaying) {
//                       _audioService.pauseAudio();
//                     } else {
//                       _audioService.playAudio();
//                     }
//                   },
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }