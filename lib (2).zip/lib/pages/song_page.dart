import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';
import '../models/playlist_provider.dart';
import '../services/audio_service.dart';

class SongPage extends StatefulWidget {
  final Song song;

  const SongPage({super.key, required this.song});

  @override
  State<SongPage> createState() => _SongPageState();
}

class _SongPageState extends State<SongPage> {
  final AudioService _audioService = AudioService();
  bool _isPlaying = false;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initAudioPlayer();
  }
  
  @override
  void dispose() {
    _audioService.disposeAudio();
    super.dispose();
  }

  Future<void> _initAudioPlayer() async {
  setState(() => _isLoading = true);
  try {
    // Try with the primary URL
    await _audioService.initAudio(widget.song.audioUrl);
    setState(() => _isLoading = false);
  } catch (e) {
    // If the primary URL fails, try an alternative gateway
    try {
      final alternativeUrl = widget.song.audioUrl.replaceFirst(
        'audius-discovery-4.cultur3stake.com',
        'discoveryprovider.audius.co'
      );
      debugPrint('Trying alternative URL: $alternativeUrl');
      await _audioService.initAudio(alternativeUrl);
      setState(() => _isLoading = false);
    } catch (e2) {
      setState(() {
        _isLoading = false;
        _error = 'Failed to load audio: $e2';
      });
    }
  }
}

  Future<void> _togglePlayPause() async {
    if (_isLoading || _error != null) return;
    
    try {
      if (_isPlaying) {
        await _audioService.pauseAudio();
      } else {
        await _audioService.playAudio();
      }
      
      setState(() => _isPlaying = !_isPlaying);
    } catch (e) {
      setState(() => _error = 'Playback error: $e');
    }
  }

  void _showAddToPlaylistDialog() {
    final playlistProvider = Provider.of<PlaylistProvider>(context, listen: false);
    final userPlaylists = playlistProvider.userPlaylists;
    
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.playlist_add),
              title: const Text('Create new playlist'),
              onTap: () {
                Navigator.pop(context);
                _createAndAddToPlaylist();
              },
            ),
            const Divider(),
            Expanded(
              child: userPlaylists.isEmpty
                  ? const Center(child: Text('No existing playlists'))
                  : ListView.builder(
                      itemCount: userPlaylists.length,
                      itemBuilder: (context, index) {
                        final playlist = userPlaylists[index];
                        return ListTile(
                          leading: const Icon(Icons.playlist_play),
                          title: Text(playlist.name),
                          subtitle: Text('${playlist.songCount} songs'),
                          trailing: playlist.containsSong(widget.song.id)
                              ? const Icon(Icons.check, color: Colors.green)
                              : null,
                          onTap: () {
                            playlistProvider.setCurrentPlaylist(playlist);
                            playlistProvider.addToPlaylist(widget.song);
                            
                            // Update the playlist in Firebase
                            if (playlist.id != null) {
                              playlistProvider.updateCurrentPlaylist();
                            }
                            
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Added to ${playlist.name}')),
                            );
                          },
                        );
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
  
  void _createAndAddToPlaylist() {
    showDialog(
      context: context,
      builder: (context) {
        final nameController = TextEditingController();
        return AlertDialog(
          title: const Text('Create New Playlist'),
          content: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              labelText: 'Playlist Name',
            ),
            autofocus: true,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                final name = nameController.text.trim();
                if (name.isNotEmpty) {
                  final provider = Provider.of<PlaylistProvider>(context, listen: false);
                  provider.createNewPlaylist(name);
                  provider.addToPlaylist(widget.song);
                  
                  // Save the new playlist to Firebase
                  provider.savePlaylist();
                  
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Added to $name')),
                  );
                }
              },
              child: const Text('Create'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Now Playing'),
        actions: [
          IconButton(
            icon: const Icon(Icons.playlist_add),
            onPressed: _showAddToPlaylistDialog,
            tooltip: 'Add to playlist',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Album art
            Expanded(
              flex: 4,
              child: Center(
                child: Hero(
                  tag: 'song_image_${widget.song.id}',
                  child: widget.song.imageUrl.isNotEmpty
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            widget.song.imageUrl,
                            width: 300,
                            height: 300,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Icon(
                              Icons.music_note,
                              size: 150,
                              color: Colors.grey,
                            ),
                          ),
                        )
                      : const Icon(
                          Icons.music_note,
                          size: 150,
                          color: Colors.grey,
                        ),
                ),
              ),
            ),
            
            // Error message
            if (_error != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Text(
                  _error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                  textAlign: TextAlign.center,
                ),
              ),
            
            // Song details
            Expanded(
              flex: 2,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    widget.song.title,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.song.artist,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey[600],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  
                  // Playback controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.skip_previous),
                        iconSize: 40,
                        onPressed: null, // Not implemented
                      ),
                      const SizedBox(width: 16),
                      _isLoading
                          ? const CircularProgressIndicator()
                          : IconButton(
                              icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled),
                              iconSize: 60,
                              color: Theme.of(context).primaryColor,
                              onPressed: _error == null ? _togglePlayPause : null,
                            ),
                      const SizedBox(width: 16),
                      IconButton(
                        icon: const Icon(Icons.skip_next),
                        iconSize: 40,
                        onPressed: null, // Not implemented
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}