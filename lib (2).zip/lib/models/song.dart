class Song {
  final String id;
  final String title;
  final String artist;
  final String imageUrl;
  final String audioUrl;

  Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.imageUrl,
    required this.audioUrl,
  });

  factory Song.fromAudiusJson(Map<String, dynamic> json) {
  // Handle null fields with nullish coalescing
  final user = json['user'] as Map<String, dynamic>?;
  final artwork = json['artwork'] as Map<String, dynamic>?;
  
  // Use the track ID directly with the streaming API
  String audioUrl = '';
  if (json['id'] != null) {
    // Direct streaming URL format
    audioUrl = 'https://audius-discovery-4.cultur3stake.com/v1/tracks/${json['id']}/stream';
  }
  
  // Get the best available artwork
  String imageUrl = '';
  if (artwork != null) {
    // Try different sizes
    imageUrl = artwork['1000x1000']?.toString() ?? 
              artwork['480x480']?.toString() ?? 
              artwork['150x150']?.toString() ?? '';
  }
  
  return Song(
    id: json['id']?.toString() ?? '',
    title: json['title']?.toString() ?? 'Unknown Title',
    artist: user?['name']?.toString() ?? user?['handle']?.toString() ?? 'Unknown Artist',
    imageUrl: imageUrl,
    audioUrl: audioUrl,
  );
}

  factory Song.fromJson(Map<String, dynamic> json) {
    return Song(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Unknown Title',
      artist: json['artist']?.toString() ?? 'Unknown Artist',
      imageUrl: json['imageUrl']?.toString() ?? '',
      audioUrl: json['audioUrl']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'artist': artist,
      'imageUrl': imageUrl,
      'audioUrl': audioUrl,
    };
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Song &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}