import 'package:audioplayers/audioplayers.dart';

class AudioService {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isInitialized = false;
  
  Future<void> initAudio(String url) async {
    if (url.isEmpty) {
      throw Exception('Audio URL is empty');
    }
    
    try {
      await _audioPlayer.setSourceUrl(url);
      _isInitialized = true;
    } catch (e) {
      _isInitialized = false;
      rethrow;
    }
  }
  
  Future<void> playAudio() async {
    if (!_isInitialized) {
      throw Exception('Audio player not initialized');
    }
    await _audioPlayer.resume();
  }
  
  Future<void> pauseAudio() async {
    if (!_isInitialized) return;
    await _audioPlayer.pause();
  }
  
  Future<void> disposeAudio() async {
    await _audioPlayer.stop();
    await _audioPlayer.dispose();
    _isInitialized = false;
  }
}