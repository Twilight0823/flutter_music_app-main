    import 'package:flutter/material.dart';
    import 'package:firebase_auth/firebase_auth.dart';
    import 'package:cloud_firestore/cloud_firestore.dart';
    import 'package:intl/intl.dart';
    import 'package:music_app/auth/login.dart';


    class Register extends StatefulWidget {
    const Register({super.key});

    @override
    State<Register> createState() => RegisterState();
    }

    class RegisterState extends State<Register> {
    final _formKey = GlobalKey<FormState>();
    final TextEditingController _emailController = TextEditingController();
    final TextEditingController _passwordController = TextEditingController();
    final TextEditingController _confirmPasswordController = TextEditingController();
    final TextEditingController _ageController = TextEditingController();
    
    
    DateTime? _selectedDate;
    String? _selectedGender;
    
    bool _isLoading = false;
    String _errorMessage = '';
    bool _obscurePassword = true;
    bool _obscureConfirmPassword = true;
    
    final FirebaseAuth _auth = FirebaseAuth.instance;
    final FirebaseFirestore _firestore = FirebaseFirestore.instance;
    
    final List<String> _genders = ['Male', 'Female', 'Prefer not to say'];

    @override
    void dispose() {
        _emailController.dispose();
        _passwordController.dispose();
        _confirmPasswordController.dispose();
        _ageController.dispose();
        super.dispose();
    }

    // Calculate age based on birthdate
    void _calculateAge() {
        if (_selectedDate != null) {
        final DateTime now = DateTime.now();
        int age = now.year - _selectedDate!.year;
        
        // Adjust age if birthday hasn't occurred yet this year
        if (now.month < _selectedDate!.month || 
            (now.month == _selectedDate!.month && now.day < _selectedDate!.day)) {
            age--;
        }
        
        setState(() {
            _ageController.text = age.toString();
        });
        }
    }

    // Date picker
    Future<void> _selectDate(BuildContext context) async {
        final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now().subtract(const Duration(days: 365 * 18)), // Default to 18 years ago
        firstDate: DateTime(1900),
        lastDate: DateTime.now(),
        builder: (context, child) {
            return Theme(
            data: ThemeData.light().copyWith(
                colorScheme: ColorScheme.light(
                primary: Theme.of(context).primaryColor,
                ),
            ),
            child: child!,
            );
        },
        );
        
        if (picked != null && picked != _selectedDate) {
        setState(() {
            _selectedDate = picked;
            _calculateAge();
        });
        }
    }

    // Register with email and password
    Future<void> _register() async {
        if (_formKey.currentState!.validate()) {
        if (_selectedGender == null) {
            setState(() {
            _errorMessage = 'Please select a gender';
            });
            return;
        }
        
        if (_selectedDate == null) {
            setState(() {
            _errorMessage = 'Please select your birth date';
            });
            return;
        }
        
        setState(() {
            _isLoading = true;
            _errorMessage = '';
        });

        try {
            // Create user with email and password
            final UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
            email: _emailController.text.trim(),
            password: _passwordController.text,
            );
            
            // Store additional user information in Firestore
            await _firestore.collection('users').doc(userCredential.user!.uid).set({
            'email': _emailController.text.trim(),
            'gender': _selectedGender,
            'birthdate': Timestamp.fromDate(_selectedDate!),
            'age': int.parse(_ageController.text),
            // 'created_at': FieldValue.serverTimestamp(),
            });
            
            // Navigate to home screen or login screen after successful registration
            if (!mounted) return;
            
            // Show success message before navigation
            ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Registration successful! Please login.'),
                backgroundColor: Colors.green,
            ),
            );
            
            // Navigate to login screen
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Login()));
        } on FirebaseAuthException catch (e) {
            String message;
            
            switch (e.code) {
            case 'email-already-in-use':
                message = 'This email is already registered.';
                break;
            case 'weak-password':
                message = 'Password is too weak. Please choose a stronger password.';
                break;
            case 'invalid-email':
                message = 'Invalid email address.';
                break;
            default:
                message = e.message ?? 'An error occurred during registration.';
            }
            
            setState(() {
            _errorMessage = message;
            });
        } catch (e) {
            setState(() {
            _errorMessage = 'An unexpected error occurred.';
            });
        } finally {
            if (mounted) {
            setState(() {
                _isLoading = false;
            });
            }
        }
        }
    }

    @override
    Widget build(BuildContext context) {
        return Scaffold(
        appBar: AppBar(
            title: const Text('Create Account'),
            elevation: 0,
        ),
        body: Center(
            child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                // App logo or icon
                Icon(
                    Icons.person_add_outlined,
                    size: 80,
                    color: Theme.of(context).primaryColor,
                ),
                const SizedBox(height: 24),
                
                // Title
                Text(
                    'Create New Account',
                    style: Theme.of(context).textTheme.headlineMedium,
                    textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                    'Please fill in the form to register',
                    style: Theme.of(context).textTheme.bodyLarge,
                    textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                
                // Error message
                if (_errorMessage.isNotEmpty)
                    Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                        color: Colors.red.shade100,
                        borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                        _errorMessage,
                        style: const TextStyle(color: Colors.red),
                    ),
                    ),
                
                // Registration form
                Form(
                    key: _formKey,
                    child: Column(
                    children: [
                        // Email
                        TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(
                            labelText: 'Email',
                            prefixIcon: Icon(Icons.email_outlined),
                            border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                            if (value == null || value.isEmpty) {
                            return 'Please enter your email';
                            }
                            if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                            return 'Please enter a valid email';
                            }
                            return null;
                        },
                        ),
                        const SizedBox(height: 16),
                        
                        // Password
                        TextFormField(
                        controller: _passwordController,
                        obscureText: _obscurePassword,
                        decoration: InputDecoration(
                            labelText: 'Password',
                            prefixIcon: const Icon(Icons.lock_outline),
                            suffixIcon: IconButton(
                            icon: Icon(
                                _obscurePassword ? Icons.visibility_off : Icons.visibility,
                            ),
                            onPressed: () {
                                setState(() {
                                _obscurePassword = !_obscurePassword;
                                });
                            },
                            ),
                            border: const OutlineInputBorder(),
                        ),
                        validator: (value) {
                            if (value == null || value.isEmpty) {
                            return 'Please enter a password';
                            }
                            if (value.length < 6) {
                            return 'Password must be at least 6 characters';
                            }
                            return null;
                        },
                        ),
                        const SizedBox(height: 16),
                        
                        // Confirm Password
                        TextFormField(
                        controller: _confirmPasswordController,
                        obscureText: _obscureConfirmPassword,
                        decoration: InputDecoration(
                            labelText: 'Confirm Password',
                            prefixIcon: const Icon(Icons.lock_outline),
                            suffixIcon: IconButton(
                            icon: Icon(
                                _obscureConfirmPassword ? Icons.visibility_off : Icons.visibility,
                            ),
                            onPressed: () {
                                setState(() {
                                _obscureConfirmPassword = !_obscureConfirmPassword;
                                });
                            },
                            ),
                            border: const OutlineInputBorder(),
                        ),
                        validator: (value) {
                            if (value == null || value.isEmpty) {
                            return 'Please confirm your password';
                            }
                            if (value != _passwordController.text) {
                            return 'Passwords do not match';
                            }
                            return null;
                        },
                        ),
                        const SizedBox(height: 16),
                        
                        // Gender selection
                        DropdownButtonFormField<String>(
                        value: _selectedGender,
                        decoration: const InputDecoration(
                            labelText: 'Gender',
                            prefixIcon: Icon(Icons.people_outline),
                            border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                            if (value == null || value.isEmpty) {
                            return 'Please select Gender';
                            }
                            return null;
                        },
                        items: _genders.map((String gender) {
                            return DropdownMenuItem<String>(
                            value: gender,
                            child: Text(gender),
                            );
                        }).toList(),
                        onChanged: (String? newValue) {
                            setState(() {
                            _selectedGender = newValue;
                            });
                        },
                        ),
                        const SizedBox(height: 16),
                        
                        // Birth date
                        InkWell( 
                        onTap: () => _selectDate(context),
                        
                        child: InputDecorator(
                            decoration: const InputDecoration(
                            labelText: 'Birth Date',
                            prefixIcon: Icon(Icons.calendar_today),
                            border: OutlineInputBorder(),
                            ),
                            child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                                Text(
                                _selectedDate == null
                                    ? 'Select Date'
                                    : DateFormat('dd/MM/yyyy').format(_selectedDate!),
                                ),
                                const Icon(Icons.arrow_drop_down),
                            ],
                            ),
                        ),
                        ),
                        const SizedBox(height: 16),
                        
                        
                        // Age (auto-calculated and read-only)
                        TextFormField(
                        controller: _ageController,
                        readOnly: true,
                        decoration: const InputDecoration(
                            labelText: 'Age',
                            prefixIcon: Icon(Icons.person_outline),
                            border: OutlineInputBorder(),
                            hintText: 'Auto-calculated from birth date',
                        ),
                        ),
                        const SizedBox(height: 24),
                        
                        // Register button
                        SizedBox(
                        height: 50,
                        child: ElevatedButton(
                            onPressed: _isLoading ? null : _register,
                            style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                            ),
                            ),
                            child: _isLoading
                                ? const CircularProgressIndicator()
                                : const Text(
                                    'Register',
                                    style: TextStyle(fontSize: 16),
                                ),
                        ),
                        ),
                    ],
                    ),
                ),
                
                const SizedBox(height: 16),
                
                // Login link
                Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                    const Text("Already have an account?"),
                    TextButton(
                        onPressed: () {
                        // Navigate to login screen
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Login()));
                        },
                        child: const Text('Login Here'),
                    ),
                    ],
                ),
                ],
            ),
            ),
        ),
        );
    }
    }