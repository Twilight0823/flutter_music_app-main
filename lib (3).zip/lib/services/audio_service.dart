// Create this as a new file: lib/services/audio_service.dart
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';

class AudioService {
  final AudioPlayer _player = AudioPlayer();
  
  Future<void> initAudio(String url) async {
    try {
      // Set up metadata for background playback notification
      final audioSource = AudioSource.uri(
        Uri.parse(url),
        tag: MediaItem(
          id: url,
          title: 'Now Playing',
          artist: 'Unknown Artist',
          // Add album and artUri if you have them available
        ),
      );
      
      await _player.setAudioSource(audioSource);
    } catch (e) {
      debugPrint('Error initializing audio: $e');
      rethrow;
    }
  }
  
  Future<void> playAudio() async {
    try {
      await _player.play();
    } catch (e) {
      debugPrint('Error playing audio: $e');
      rethrow;
    }
  }
  
  Future<void> pauseAudio() async {
    try {
      await _player.pause();
    } catch (e) {
      debugPrint('Error pausing audio: $e');
      rethrow;
    }
  }
  
  Future<void> disposeAudio() async {
    await _player.stop();
    await _player.dispose();
  }
}