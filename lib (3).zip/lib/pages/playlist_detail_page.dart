import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';
import '../providers/playlist_provider.dart';
import 'song_page.dart';

class PlaylistDetailPage extends StatefulWidget {
  const PlaylistDetailPage({super.key});

  @override
  State<PlaylistDetailPage> createState() => _PlaylistDetailPageState();
}

class _PlaylistDetailPageState extends State<PlaylistDetailPage> {
  final TextEditingController _renameController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _renameController.dispose();
    super.dispose();
  }

  void _renamePlaylist(BuildContext context, String currentName) {
    _renameController.text = currentName;
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Rename Playlist'),
          content: TextField(
            controller: _renameController,
            decoration: const InputDecoration(
              labelText: 'New Name',
              hintText: 'Enter new playlist name',
            ),
            autofocus: true,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('CANCEL'),
            ),
            TextButton(
              onPressed: () {
                final newName = _renameController.text.trim();
                if (newName.isNotEmpty) {
                  Provider.of<PlaylistProvider>(context, listen: false)
                      .renamePlaylist(newName);
                  Navigator.pop(context);
                }
              },
              child: const Text('RENAME'),
            ),
          ],
        );
      },
    );
  }

  void _showShareOptions(BuildContext context) {
    final playlist = Provider.of<PlaylistProvider>(context, listen: false).currentPlaylist;
    
    if (playlist.id == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Save the playlist first to share it'),
        ),
      );
      return;
    }
    
    final shareLink = playlist.generateShareLink();
    
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Share Playlist',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Text(
                shareLink,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.copy),
                    label: const Text('Copy Link'),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: shareLink));
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Link copied to clipboard')),
                      );
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _savePlaylist(BuildContext context) async {
    setState(() => _isLoading = true);
    
    try {

      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Playlist saved successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save playlist: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _updatePlaylist(BuildContext context) async {
    setState(() => _isLoading = true);
    
    try {
      final playlistProvider = Provider.of<PlaylistProvider>(context, listen: false);
      await playlistProvider.updateCurrentPlaylist();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Playlist updated successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update playlist: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showDeleteConfirmation(BuildContext context, String? playlistId) {
    if (playlistId == null) {
      Navigator.pop(context); // Just go back if not saved
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Delete Playlist'),
          content: const Text('Are you sure you want to delete this playlist? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('CANCEL'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context); // Close dialog
                
                final playlistProvider = Provider.of<PlaylistProvider>(context, listen: false);
                await playlistProvider.deletePlaylist(playlistId);
                
                if (mounted) {
                  Navigator.pop(context); // Go back to home
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Playlist deleted')),
                  );
                }
              },
              child: const Text('DELETE', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  void _navigateToSongPage(BuildContext context, Song song) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SongPage(song: song)),
    );
  }

  void _reorderSongs(int oldIndex, int newIndex, PlaylistProvider provider) {
    final currentPlaylist = provider.currentPlaylist;
    final songs = List<Song>.from(currentPlaylist.songs);
    
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    
    final Song song = songs.removeAt(oldIndex);
    songs.insert(newIndex, song);
    
    provider.setCurrentPlaylist(currentPlaylist.copyWith(songs: songs));
  }

  Widget _buildEmptyPlaylist() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.playlist_add, size: 80, color: Colors.grey),
          const SizedBox(height: 16),
          const Text(
            'This playlist is empty',
            style: TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 8),
          const Text(
            'Search for songs to add them here',
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('GO TO SEARCH'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PlaylistProvider>(
      builder: (context, playlistProvider, child) {
        final playlist = playlistProvider.currentPlaylist;
        final songs = playlist.songs;
        
        return Scaffold(
          appBar: AppBar(
            title: Text(playlist.name),
            actions: [
              // Toggle visibility
              IconButton(
                icon: Icon(playlist.isPublic ? Icons.public : Icons.lock),
                onPressed: () => playlistProvider.toggleVisibility(),
                tooltip: playlist.isPublic ? 'Make private' : 'Make public',
              ),
              
              // Share button
              IconButton(
                icon: const Icon(Icons.share),
                onPressed: playlist.id == null
                    ? null
                    : () => _showShareOptions(context),
                tooltip: 'Share playlist',
              ),
              
              // More options
              PopupMenuButton<String>(
                onSelected: (value) {
                  switch (value) {
                    case 'rename':
                      _renamePlaylist(context, playlist.name);
                      break;
                    case 'save':
                      _savePlaylist(context);
                      break;
                    case 'update':
                      _updatePlaylist(context);
                      break;
                    case 'delete':
                      _showDeleteConfirmation(context, playlist.id);
                      break;
                    case 'clear':
                      playlistProvider.clearPlaylist();
                      break;
                  }
                },
                itemBuilder: (context) => <PopupMenuEntry<String>>[
                  const PopupMenuItem<String>(
                    value: 'rename',
                    child: ListTile(
                      leading: Icon(Icons.edit),
                      title: Text('Rename'),
                    ),
                  ),
                  if (playlist.id == null)
                    const PopupMenuItem<String>(
                      value: 'save',
                      child: ListTile(
                        leading: Icon(Icons.save),
                        title: Text('Save'),
                      ),
                    )
                  else
                    const PopupMenuItem<String>(
                      value: 'update',
                      child: ListTile(
                        leading: Icon(Icons.update),
                        title: Text('Update'),
                      ),
                    ),
                  const PopupMenuItem<String>(
                    value: 'clear',
                    child: ListTile(
                      leading: Icon(Icons.clear_all),
                      title: Text('Clear all'),
                    ),
                  ),
                  if (playlist.id != null)
                    const PopupMenuItem<String>(
                      value: 'delete',
                      child: ListTile(
                        leading: Icon(Icons.delete, color: Colors.red),
                        title: Text('Delete', style: TextStyle(color: Colors.red)),
                      ),
                    ),
                ],
              ),
            ],
          ),
          body: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : songs.isEmpty 
                  ? _buildEmptyPlaylist()
                  : ReorderableListView.builder(
                      itemCount: songs.length,
                      itemBuilder: (context, index) {
                        final song = songs[index];
                        return ListTile(
                          key: Key(song.id),
                          leading: song.imageUrl.isNotEmpty
                              ? Hero(
                                  tag: 'song_image_${song.id}',
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(4),
                                    child: Image.network(
                                      song.imageUrl,
                                      width: 50,
                                      height: 50,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => const Icon(Icons.music_note),
                                    ),
                                  ),
                                )
                              : const Icon(Icons.music_note),
                          title: Text(song.title),
                          subtitle: Text(song.artist),
                          trailing: IconButton(
                            icon: const Icon(Icons.remove_circle_outline),
                            onPressed: () => playlistProvider.removeFromPlaylist(song.id),
                          ),
                          onTap: () => _navigateToSongPage(context, song),
                        );
                      },
                      onReorder: (oldIndex, newIndex) => _reorderSongs(oldIndex, newIndex, playlistProvider),
                    ),
        );
      },
    );
  }
}